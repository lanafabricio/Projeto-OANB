function pass(){
if(document.password.nome.value=="curso" && document.password.senha.value=="hist001/2005")
window.open('hist_africa.html','_blank')
else
window.open('erro.html','_self')
}